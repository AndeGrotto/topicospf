import React, { useState, useEffect, useRef } from "react";

function Home() {

  return(
     <div>
         <h1>Bem vindo</h1>
     </div>
  );

}
export default Home;
