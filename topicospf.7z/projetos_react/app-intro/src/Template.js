import React, { useState } from 'react';

function Template() {
  // Declare variáveis de state
  

  return (
    <div>
     

      
    </div>
  );
}

export default Template;